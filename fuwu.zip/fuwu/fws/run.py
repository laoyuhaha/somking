# -*- coding:utf-8 -*-

import unittest
import HTMLTestRunnerNew
import os
from common import constant


class RunTestCase:

    def load_TestCase(self):
        case_dir = constant.case_dir
        discover = unittest.defaultTestLoader.discover(case_dir,pattern='test*.py')
        return discover

    def print_report(self,file):
        with open(file,'wb') as files:
            runner = HTMLTestRunnerNew.HTMLTestRunner(stream=files,title='测试报告',
                                                      description='服务商的登录',tester='yuchengwen')
            runner.run(self.load_TestCase())


if __name__ == '__main__':
    RunTestCase().print_report(os.path.join(constant.report_dir,'test_report.html'))




